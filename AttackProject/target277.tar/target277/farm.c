/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_240(unsigned x)
{
    return x + 2462550344U;
}

unsigned getval_207()
{
    return 3284633928U;
}

void setval_353(unsigned *p)
{
    *p = 2425393240U;
}

unsigned addval_255(unsigned x)
{
    return x + 1489479557U;
}

unsigned getval_452()
{
    return 2663616584U;
}

unsigned addval_410(unsigned x)
{
    return x + 2425393752U;
}

void setval_134(unsigned *p)
{
    *p = 2428995912U;
}

void setval_403(unsigned *p)
{
    *p = 3267856712U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_363(unsigned x)
{
    return x + 3569601033U;
}

unsigned addval_245(unsigned x)
{
    return x + 2462746949U;
}

unsigned addval_421(unsigned x)
{
    return x + 3599472568U;
}

unsigned getval_464()
{
    return 3247035184U;
}

void setval_118(unsigned *p)
{
    *p = 2447411528U;
}

unsigned addval_427(unsigned x)
{
    return x + 2428600611U;
}

unsigned getval_432()
{
    return 3230974345U;
}

void setval_125(unsigned *p)
{
    *p = 3524840073U;
}

unsigned getval_429()
{
    return 3682912905U;
}

void setval_121(unsigned *p)
{
    *p = 2425542281U;
}

void setval_249(unsigned *p)
{
    *p = 3523791497U;
}

unsigned addval_388(unsigned x)
{
    return x + 3286239560U;
}

unsigned getval_390()
{
    return 3767091293U;
}

unsigned getval_369()
{
    return 3221804683U;
}

void setval_309(unsigned *p)
{
    *p = 2425408169U;
}

unsigned getval_482()
{
    return 2464188744U;
}

void setval_227(unsigned *p)
{
    *p = 2430634313U;
}

void setval_122(unsigned *p)
{
    *p = 3252062561U;
}

unsigned getval_112()
{
    return 3229144713U;
}

unsigned addval_499(unsigned x)
{
    return x + 3284240774U;
}

void setval_348(unsigned *p)
{
    *p = 3372796425U;
}

void setval_290(unsigned *p)
{
    *p = 3372799625U;
}

void setval_446(unsigned *p)
{
    *p = 3375939981U;
}

unsigned getval_138()
{
    return 2425405837U;
}

unsigned addval_395(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_166()
{
    return 3676881289U;
}

void setval_460(unsigned *p)
{
    *p = 3598794575U;
}

void setval_173(unsigned *p)
{
    *p = 3223374537U;
}

void setval_356(unsigned *p)
{
    *p = 3221799304U;
}

void setval_181(unsigned *p)
{
    *p = 3286272330U;
}

unsigned addval_129(unsigned x)
{
    return x + 3599305804U;
}

unsigned addval_107(unsigned x)
{
    return x + 3286272328U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
